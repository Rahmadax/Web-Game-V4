package main

import (
	"game/Orchestrator/pkg"
)

func main() {
	orch, err := pkg.NewOrchestrator()
	if err != nil {
		return
	}

	orch.Start(":50000")
}
