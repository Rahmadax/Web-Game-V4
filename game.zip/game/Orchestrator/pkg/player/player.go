package player

import (
	"net/http"

	"github.com/gin-gonic/gin"
)

type TestController interface {
}

func (router *router) AddEndpoints(route *gin.Engine) {
	test := route.Group("/player")
	{
		test.GET("", router.testPlayersHandler)
	}
}

func (router *router) testPlayersHandler(c *gin.Context) {
	c.JSON(http.StatusOK, "all good here!")
}
