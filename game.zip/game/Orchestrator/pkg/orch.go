package pkg

import (
	"game/Orchestrator/pkg/maps"
	"game/Orchestrator/pkg/player"
	"game/Orchestrator/pkg/test_funcs"

	"github.com/gin-gonic/gin"
)

type Orchestrator interface {
	Start()
}

type orchestrator struct {
	Router *gin.Engine
}

func NewOrchestrator() (orchestrator, error) {
	orchestrator := orchestrator{}

	router := gin.Default()

	maps.AddEndpoints(router)
	player.AddEndpoints(router)
	test_funcs.AddEndpoints(router)

	orchestrator.Router = router

	return orchestrator, nil
}

func (orchestrator *orchestrator) Start(port string) {
	err := orchestrator.Router.Run(port)
	if err != nil {
		return
	}

	return
}
