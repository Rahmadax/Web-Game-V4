package maps

import (
	"github.com/gin-gonic/gin"
)

type MapController interface {
	test()
}

func AddEndpoints(route *gin.Engine) {
	maps := route.Group("/maps")
	{
		maps.GET("", func(c *gin.Context) {
		})
	}
}
