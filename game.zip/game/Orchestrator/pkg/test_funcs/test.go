package test_funcs

import (
	"net/http"

	"github.com/gin-gonic/gin"
)

type TestController interface {
}

func AddEndpoints(route *gin.Engine) {
	test := route.Group("/test")
	{
		test.GET("", func(c *gin.Context) {
			c.JSON(http.StatusOK, "Test is all good!")
		})
	}
}
