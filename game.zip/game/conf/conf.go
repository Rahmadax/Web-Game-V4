package conf

import (
	"io/ioutil"

	"github.com/go-yaml/yaml"
)

type Configuration struct {
}

func New(configFile string) (*Configuration, error) {
	var configuration *Configuration

	file, err := ioutil.ReadFile(configFile)
	if err != nil {
		return nil, err
	}

	err = yaml.Unmarshal(file, &configuration)
	if err != nil {
		return nil, err
	}

	return configuration, nil
}
