package models

type Player struct {
	Id         string
	Username   string
	Characters []Character
}

type Character struct {
	Name  string
	Class string

}

type Map struct {
	Id      string
	TileSet [][]Tile
}

type Tile struct {
	Id string
}
